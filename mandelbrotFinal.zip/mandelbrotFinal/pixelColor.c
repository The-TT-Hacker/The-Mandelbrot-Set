#include "pixelColor.h"
#include <math.h>

unsigned char stepsToRed(int steps){
   int stepsToRed = 0;
   if(steps >= 15 && steps <= 77) {
      stepsToRed = 2 * steps;
   }
   if(steps < 15) {
      stepsToRed = pow(steps, 1.2);
   }
   return stepsToRed;
}

unsigned char stepsToGreen(int steps){
   int stepsToGreen = 0;
   if(steps >= 34 && steps <= 77) {
      stepsToGreen = steps;
   }
   if(steps < 34) {
      stepsToGreen = pow(steps, 1.2);
   }
   return stepsToGreen;
}

unsigned char stepsToBlue(int steps){
   int stepsToBlue = steps*steps/255;
   if(steps >= 42 && steps <= 75) {
     stepsToBlue = steps;
   }
   return stepsToBlue;
}