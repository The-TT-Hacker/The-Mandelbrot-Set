bits8* mandelbrot(double xCoordinate, double yCoordinate, double zoom) {
   assert(sizeof(bits8) == 1);
   assert(sizeof(bits16) == 2);
   assert(sizeof(bits32) == 4);

   bits8 byteRed;
   bits8 byteGreen;
   bits8 byteBlue;

   double x = 0;
   double y = 0;
   int size = BYTES_PER_PIXEL * SIZE * SIZE + OFFSET;
   int counter = OFFSET;
   bits8 *bmpMandelbrot = malloc(size);

   writeHeader(bmpMandelbrot);
   printf("\nFirst byte: %x", bmpMandelbrot[0]);
   
   while(y < SIZE) {
      while(x < SIZE) {

         complexNo z;
         z.re = 0;
         z.im = 0;

         complexNo c;
         c.re = x/pow(2, zoom) - (double) SIZE/pow(2, zoom)/2 + pow(1/2, zoom) + xCoordinate;
         c.im = y/pow(2, zoom) - (double) SIZE/pow(2, zoom)/2 + pow(1/2, zoom) + yCoordinate;
         
         int steps = stepsToEscape(z, c);
         byteRed   = stepsToRed(steps);
         byteGreen = stepsToGreen(steps);
         byteBlue  = stepsToBlue(steps);

         // Assigning the pixel colours as bgr because that's how bmp files seem to work
         bmpMandelbrot[counter]     = byteBlue;
         bmpMandelbrot[counter + 1] = byteGreen;
         bmpMandelbrot[counter + 2] = byteRed;

         //printf("Check 6, Counter = %d\n", counter);
         //printf("bmpMandelbrot: %u\n\n", bmpMandelbrot[counter-3]);
         //printf("Steps: %u %u %u\n", byteRed, byteGreen, byteBlue);

         x++;
         counter += 3;
      }
      x = 0;
      y++;
   }

   return bmpMandelbrot;
}

complexNo compute(complexNo z, complexNo c) {
   double real = z.re * z.re - z.im * z.im + c.re;
   double imaginary = 2 * z.re * z.im + c.im;

   z.re = real;
   z.im = imaginary;

   return z;
}

int stepsToEscape(complexNo z, complexNo c) {
   int steps = 0;
   z = compute(z, c);

   while(z.re * z.re + z.im * z.im <= 4 && steps < MAX_STEPS) {
      z = compute(z, c);
      steps++;
   }
   return steps;
}


void writeHeader(bits8 *array) {

   int n = 0;
   bits8 header[OFFSET] = {0x42, 0x4D, 
                           0x36, 0x00, 0x0C, 0x00, 
                           0x00, 0x00, 0x00, 0x00, 
                           0x36, 0x00, 0x00, 0x00, 
                           0x28, 0x00, 0x00, 0x00, 
                           0x00, 0x02, 0x00, 0x00, 
                           0x00, 0x02, 0x00, 0x00, 
                           0x01, 0x00, 
                           0x18, 0x00, 
                           0x00, 0x00, 0x00, 0x00, 
                           0x00, 0x00, 0x0C, 0x00, 
                           0x13, 0x0B, 0x00, 0x00, 
                           0x13, 0x0B, 0x00, 0x00, 
                           0x00, 0x00, 0x00, 0x00, 
                           0x00, 0x00, 0x00, 0x00};
   while (n < OFFSET) {
      array[n] = header[n];
      printf("%02x", array[n]);
      n++;
   }
}
