#include <math.h>

bits8 stepsToRed(bits8 steps){
   bits8 stepsToRed = 0;
   if(steps >= 15 && steps <= 77) {
      stepsToRed = 2*steps;
   }
   if(steps < 15) {
      stepsToRed = (bits8) pow(steps, 1.2);
   }
   return stepsToRed;
}

bits8 stepsToGreen(bits8 steps){
   bits8 stepsToGreen = 0;
   if(steps >= 34 && steps <= 77) {
      stepsToGreen = steps;
   }
   if(steps < 34) {
      stepsToGreen = (bits8) pow(steps, 1.2);
   }
   return stepsToGreen;
}

bits8 stepsToBlue(bits8 steps){
   bits8 stepsToBlue = (bits8) steps*steps/255;
   if(steps >= 42 && steps <= 75) {
     stepsToBlue = steps;
   }
   return stepsToBlue;
}