/* * xanadu.h 
   * defines the centre of your beautiful colored tile image of the mandelbrot set 
   * team members names here: Ben Henderson, Tim Thacker
   *
   *
   * your description here: Just a file defining the coordinates of a cool part of
   * the mandelbrot set. (Just one cool, part as the whole thing is cool)
   */ 

   // replace these three values with your own chosen numbers


#define CENTER_X -0.13
#define CENTER_Y 0.965
#define ZOOM 12