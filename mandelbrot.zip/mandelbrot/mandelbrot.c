#include "mandelbrot.h"
#include "pixelColor.h"

void mandelbrot(double xCoordinate, double yCoordinate, double zoom) {
   assert(sizeof(bits8) == 1);
   assert(sizeof(bits16) == 2);
   assert(sizeof(bits32) == 4);

   FILE *outputFile;

   outputFile = fopen(BMP_FILE, "wb");
   assert((outputFile != NULL) && "Cannot open file");

   writeHeader(outputFile);

   bits8 byteRed;
   bits8 byteGreen;
   bits8 byteBlue;

   double x = 0;
   double y = 0;

   while(y < SIZE) {
      while(x < SIZE) {
         complexNo z;
         z.re = 0;
         z.im = 0;

         complexNo c;
         c.re = x/pow(10, zoom) - (double) SIZE/pow(10, zoom)/2 + pow(1/2, zoom) + xCoordinate;
         c.im = y/pow(10, zoom) - (double) SIZE/pow(10, zoom)/2 + pow(1/2, zoom) + yCoordinate;
         
         int steps = stepsToEscape(z, c);
         byteRed   = stepsToRed(steps);
         byteGreen = stepsToGreen(steps);
         byteBlue  = stepsToBlue(steps);

         fwrite(&byteRed,   sizeof byteRed, 1, outputFile);
         fwrite(&byteGreen, sizeof byteGreen, 1, outputFile);
         fwrite(&byteBlue,  sizeof byteBlue, 1, outputFile);

         x++;
      }
      x = 0;
      y++;
   }
}

complexNo compute(complexNo z, complexNo c) {
   double real = z.re * z.re - z.im * z.im + c.re;
   double imaginary = 2 * z.re * z.im + c.im;

   z.re = real;
   z.im = imaginary;

   return z;
}

int stepsToEscape(complexNo z, complexNo c) {
   int steps = 0;
   z = compute(z, c);

   while(z.re * z.re + z.im * z.im <= 4 && steps < MAX_STEPS) {
      z = compute(z, c);
      steps++;
   }
   return steps;
}

void writeHeader(FILE *file) {
   assert(sizeof (bits8) == 1);
   assert(sizeof (bits16) == 2);
   assert(sizeof (bits32) == 4);
 
   bits16 magicNumber = MAGIC_NUMBER;
   fwrite(&magicNumber, sizeof magicNumber, 1, file);
 
   bits32 fileSize = OFFSET + (SIZE * SIZE * BYTES_PER_PIXEL);
   fwrite(&fileSize, sizeof fileSize, 1, file);
 
   bits32 reserved = 0;
   fwrite(&reserved, sizeof reserved, 1, file);
 
   bits32 offset = OFFSET;
   fwrite(&offset, sizeof offset, 1, file);
 
   bits32 dibHeaderSize = DIB_HEADER_SIZE;
   fwrite(&dibHeaderSize, sizeof dibHeaderSize, 1, file);
 
   bits32 width = SIZE;
   fwrite(&width, sizeof width, 1, file);
 
   bits32 height = SIZE;
   fwrite(&height, sizeof height, 1, file);
 
   bits16 planes = NUMBER_PLANES;
   fwrite(&planes, sizeof planes, 1, file);
 
   bits16 bitsPerPixel = BITS_PER_PIXEL;
   fwrite(&bitsPerPixel, sizeof bitsPerPixel, 1, file);
 
   bits32 compression = NO_COMPRESSION;
   fwrite(&compression, sizeof compression, 1, file);
 
   bits32 imageSize = (SIZE * SIZE * BYTES_PER_PIXEL);
   fwrite(&imageSize, sizeof imageSize, 1, file);
 
   bits32 hResolution = PIX_PER_METRE;
   fwrite(&hResolution, sizeof hResolution, 1, file);
 
   bits32 vResolution = PIX_PER_METRE;
   fwrite(&vResolution, sizeof vResolution, 1, file);
 
   bits32 numColors = NUM_COLORS;
   fwrite(&numColors, sizeof numColors, 1, file);
 
   bits32 importantColors = NUM_COLORS;
   fwrite(&importantColors, sizeof importantColors, 1, file);
}
