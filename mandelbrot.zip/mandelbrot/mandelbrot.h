#include "pixelColor.c"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#define BYTES_PER_PIXEL 3
#define BITS_PER_PIXEL (BYTES_PER_PIXEL*8)
#define NUMBER_PLANES 1
#define PIX_PER_METRE 2835
#define MAGIC_NUMBER 0x4d42
#define NO_COMPRESSION 0
#define OFFSET 54
#define DIB_HEADER_SIZE 40
#define NUM_COLORS 0
#define SIZE 512
#define MAX_STEPS 256
#define BMP_FILE "mandelbrot.bmp"

typedef unsigned char  bits8;
typedef unsigned short bits16;
typedef unsigned int   bits32;

typedef struct _complexNo {
   double re;
   double im;
} complexNo;

void writeHeader(FILE *file);
complexNo compute(complexNo z, complexNo c);
int stepsToEscape(complexNo z, complexNo c);

