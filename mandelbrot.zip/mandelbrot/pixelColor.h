unsigned char stepsToRed(int steps);
unsigned char stepsToBlue(int steps);
unsigned char stepsToGreen(int steps);