int stepsToRed(int steps){
   int stepsToRed = 0;
   //if(steps >= 0 && steps <= 255) {
      stepsToRed = steps;
   //}
   return stepsToRed;
}

int stepsToGreen(int steps){
   int stepsToGreen = 0;
   //if(steps >= 51 && steps <= 204) {
      stepsToGreen = steps;
   //}
   return stepsToGreen;
}

int stepsToBlue(int steps){
   int stepsToBlue = 0;
   //if(steps >= 102 && steps <= 153) {
      stepsToBlue = steps;
   //}
   return stepsToBlue;
}
