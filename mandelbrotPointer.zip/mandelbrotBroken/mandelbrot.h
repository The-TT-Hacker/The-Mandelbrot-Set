bits8* mandelbrot(double xCoordinate, double yCoordinate, double zoom) {
   assert(sizeof(bits8) == 1);
   assert(sizeof(bits16) == 2);
   assert(sizeof(bits32) == 4);

   bits8 byteRed;
   bits8 byteGreen;
   bits8 byteBlue;

   double x = 0;
   double y = 0;
   int size = BYTES_PER_PIXEL * SIZE * SIZE;
   int counter = 0;
   bits8 *bmpMandelbrot = malloc(size);
   
   while(y < SIZE) {
      while(x < SIZE) {

         complexNo z;
         z.re = 0;
         z.im = 0;

         complexNo c;
         c.re = x/pow(2, zoom) - (double) SIZE/pow(2, zoom)/2 + pow(1/2, zoom) + xCoordinate;
         c.im = y/pow(2, zoom) - (double) SIZE/pow(2, zoom)/2 + pow(1/2, zoom) + yCoordinate;
         
         bits8 steps = stepsToEscape(z, c);
         byteRed   = stepsToRed(steps);
         byteGreen = stepsToGreen(steps);
         byteBlue  = stepsToBlue(steps);

         bmpMandelbrot[counter]     = byteRed;
         bmpMandelbrot[counter + 1] = byteGreen;
         bmpMandelbrot[counter + 2] = byteBlue;

         printf("Check 6, Counter = %d\n", counter);
         printf("bmpMandelbrot: %u\n\n", bmpMandelbrot[counter-3]);
         printf("Steps: %u %u %u\n", byteRed, byteGreen, byteBlue);

         x++;
         counter += 3;
      }
      x = 0;
      y++;
   }
   return bmpMandelbrot;
}

complexNo compute(complexNo z, complexNo c) {
   double real = z.re * z.re - z.im * z.im + c.re;
   double imaginary = 2 * z.re * z.im + c.im;

   z.re = real;
   z.im = imaginary;

   return z;
}

bits8 stepsToEscape(complexNo z, complexNo c) {
   bits8 steps = 0;
   z = compute(z, c);

   while(z.re * z.re + z.im * z.im <= 4 && steps < MAX_STEPS) {
      z = compute(z, c);
      steps++;
   }
   return steps;
}