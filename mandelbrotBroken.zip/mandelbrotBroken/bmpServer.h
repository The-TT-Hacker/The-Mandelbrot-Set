#include <stdlib.h>
#include <stdio.h>
#include <netinet/in.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <assert.h>
#include <math.h>

//mandelbrot.h
#define BYTES_PER_PIXEL 3
#define BITS_PER_PIXEL (BYTES_PER_PIXEL * 8)
#define NUMBER_PLANES 1
#define PIX_PER_METRE 2835
#define MAGIC_NUMBER 0x4d42
#define NO_COMPRESSION 0
#define OFFSET 54
#define DIB_HEADER_SIZE 40
#define NUM_COLORS 0
#define SIZE 512
#define MAX_STEPS 256
#define BMP_FILE "mandelbrot.bmp"

//bmpServer.c
#define SIMPLE_SERVER_VERSION 1.0
#define REQUEST_BUFFER_SIZE 2000
#define DEFAULT_PORT 1917
#define NUMBER_OF_PAGES_TO_SERVE 10000

 //mandelbrot.h
struct _complexNo{
   double re;
   double im;
};

//mandelbrot.h
typedef unsigned char  bits8;
typedef unsigned short bits16;
typedef unsigned int   bits32;
typedef struct _complexNo complexNo;

 //mandelbrot.h
complexNo compute(complexNo z, complexNo c);
bits8 stepsToEscape(complexNo z, complexNo c);
void writeHeader(FILE *file);

 //bmpServer.c
int waitForConnection(int serverSocket);
int makeServerSocket(int portno);
void serveBMP(int socket, double xCoord, double yCoord, int zoom);
static void serveHTML (int socket);